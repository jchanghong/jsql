/*! grafana - v4.3.1 - 2017-05-23
 * Copyright (c) 2017 Torkel Ödegaard; Licensed Apache-2.0 */

System.register([],function(a,b){"use strict";var c;b&&b.id;return{setters:[],execute:function(){c=function(){function a(a){var b=null;this.lazy=["$q","$route","$rootScope",function(c,d,e){return b?b.promise:(b=c.defer(),System.import(a).then(function(){b.resolve()}),b.promise)}]}return a}(),a("BundleLoader",c)}}});