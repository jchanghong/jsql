declare var _default: string[];
export default _default;
